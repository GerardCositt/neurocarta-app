<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name') }}</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.2/tailwind.min.css">

</head>
<body class="bg-gray-800">

<!-- Section 1 -->
<section
    class="relative py-16 bg-gradient-to-r from-gray-400 to-gray-900 min-w-screen animation-fade animation-delay align-middle">
    <div class="container px-0 px-8 mx-auto sm:px-12 xl:px-5">
        <p class="text-xs font-bold text-left text-yellow-500 uppercase sm:mx-6 sm:text-center sm:text-normal sm:font-bold">
            Marisquería </p>
        <h3 class="mt-1 text-2xl font-bold text-left text-yellow-50 sm:mx-6 sm:text-3xl md:text-4xl lg:text-5xl sm:text-center sm:mx-0">
            {{ config('app.name') }}
        </h3>
        <div class="mt-6" x-data="{ open: {{$showAlerts ? 'true':'false'}} }">
            <!-- Button -->
            @if($advices->count() > 0)
                <button
                    class="md:max-w-2xl  mx-auto flex  md:flex-nowrap items-center text-xs font-bold text-center text-yellow-500 uppercase sm:text-center sm:font-bold"
                    @click="open = true">Mostrar avisos
                </button>
                <!-- Dialog (full screen) -->
                <div class="absolute top-0 left-0 flex items-baseline justify-center w-full h-full"
                     style="background-color: rgba(0,0,0,.5);" x-show="open">
                    <!-- A basic modal dialog with title, body and one button to close -->
                    <div class="h-auto p-4 mx-2 text-left bg-white rounded shadow-xl md:max-w-xl md:p-6 lg:p-8 md:mx-0"
                         @click.away="open = false">
                        @foreach($advices as $advice)
                            <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                                <h3 class="text-lg font-medium leading-6 text-gray-900">{{$advice->title}}</h3>
                                <div class="mt-2">
                                    <p class="text-sm leading-5 text-gray-500">{{$advice->advice}}</p>
                                </div>
                            </div>
                            <br/>
                        @endforeach
                    <!-- One big close button.  --->
                        <div class="mt-5 sm:mt-6">
                        <span class="flex w-full rounded-md shadow-sm">
                            <button @click="open = false"
                                    class="inline-flex justify-center w-full px-4 py-2 text-white bg-yellow-500 rounded hover:bg-yellow-700">
                            Cerrar aviso
                            </button>
                        </span>
                        </div>
                    </div>
                </div>
            @endif
        </div>
        <br/>
        @if($showOffer)
            <section
                class=" md:max-w-2xl  mx-auto flex  md:flex-nowrap items-center bg-gray-800 shadow-lg rounded-2xl py-6 md:py-4 px-6 md:pr-5 space-y-6 md:space-y-0 md:space-x-2">
                <p class="flex-auto text-yellow-500 text-lg font-medium align-middle">
                    Ofertas</p>
                <a href="{{route('offer')}}"
                   class="flex-none bg-yellow-500 hover:bg-gray-100 transition-colors duration-200 text-gray-900 font-semibold rounded-lg py-3 px-4 align-middle">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" width="28" height="28"
                         stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M13 5l7 7-7 7M5 5l7 7-7 7"/>
                    </svg>
                </a>
            </section>
            <br/>
        @endif
        @foreach($categories as $category)
            @if ($category->products->count() >= 1)


                <section
                    class=" md:max-w-2xl  mx-auto flex  md:flex-nowrap items-center bg-gray-800 shadow-lg rounded-2xl py-6 md:py-4 px-6 md:pr-5 space-y-6 md:space-y-0 md:space-x-2 align-middle">
                    <p class="flex-auto text-yellow-500 text-lg font-medium align-middle"><a
                            href="/list/{{$category->id}}">
                            {{$category->name}}</a></p>
                    @if($categories->count() == 1)
                        <a href="/"
                           class="flex-none bg-yellow-500 align-middle hover:bg-gray-100 transition-colors duration-200 text-gray-900 font-semibold rounded-lg py-3 px-4 align-middle">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" width="28"
                                 height="28" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                      d="M11 19l-7-7 7-7m8 14l-7-7 7-7"/>
                            </svg>
                        </a>
                    @else
                        <a href="{{route('menulist',$category)}}"
                           class="flex-none bg-yellow-500 hover:bg-gray-100 transition-colors duration-200 text-gray-900 font-semibold rounded-lg py-3 px-4 align-middle">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" width="28"
                                 height="28" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                      d="M13 5l7 7-7 7M5 5l7 7-7 7"/>
                            </svg>
                        </a>
                    @endif
                </section>
                <br/>
            @endif
            @if($categories->count() == 1)
                @foreach( $category->products as $product)
                    @if ($product->active == 0)
                        <div class="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden md:max-w-2xl">

                            <div class="md:flex">
                                <div class="md:flex-shrink-0 bg-red-500">
                                    <img class="h-48 w-full object-cover md:w-48"
                                         src="/storage/{{$product->photo ? $product->photo : 'img/noimg.png'}}"
                                         alt="{{$product->name}}">
                                </div>
                                <div class="p-8">
                                    @if($product->offer)
                                        <div class="animate-bounce flex space-x-5">
                                            <div class="uppercase tracking-wide text-sm text-red-500 font-semibold">
                                                Oferta
                                            </div>
                                        </div>
                                    @else
                                        <div
                                            class="uppercase tracking-wide text-sm text-indigo-500 font-semibold"></div>
                                    @endif
                                    <a href="#"
                                       class="block mt-1 text-lg leading-tight font-medium text-black hover:underline">{{$product->name}}</a>
                                    <p class="mt-2 text-gray-500">{{$product->description}}
                                        @if ($product->aller)
                                            <br/>Alérgenos: {{$product->aller}}
                                        @endif
                                        @if ($product->pairing_id)
                                            <br/>Maridaje: {{$product->pairing->description}}
                                        @endif
                                    </p>
                                    @if ($product->offer)
                                        <p class="text-right line-through">Precio: {{$product->price}}</p>
                                        <p class=" uppercase tracking-wide text-sm text-red-500 font-semibold text-right">
                                            Oferta: {{$product->offer_price}}</p>
                                    @else
                                        <p class=" uppercase tracking-wide text-sm text-black font-semibold text-right">
                                            Precio: {{$product->price}}</p>

                                    @endif
                                </div>
                            </div>
                        </div>
                        <br/>
                    @endif
                @endforeach
            @endif
        @endforeach

    </div>
    <div class="copyright text-center text-white">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script>
        , made with <span class=" align-middle	 text-3xl text-red-500 ">♥</span> by
        <a href="https://cositt.com/" target="_blank">Cositt Technology&reg;</a> for a better web.
    </div>
</section>

<!-- AlpineJS Library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/alpinejs/2.8.0/alpine.js"></script>

</body>
</html>
