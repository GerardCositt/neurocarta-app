<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name') }}</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.2/tailwind.min.css">

</head>
<body class="bg-gray-800">

<!-- Section 1 -->
<section class="relative py-16 bg-gradient-to-r from-gray-400 to-gray-900 min-w-screen animation-fade animation-delay align-middle">
    <div class="container px-0 px-8 mx-auto sm:px-12 xl:px-5">
        <p class="text-xs font-bold text-left text-yellow-500 uppercase sm:mx-6 sm:text-center sm:text-normal sm:font-bold">
            Marisquería
        </p>
        <h3 class="mt-1 text-2xl font-bold text-left text-yellow-50 sm:mx-6 sm:text-3xl md:text-4xl lg:text-5xl sm:text-center sm:mx-0">
            {{ config('app.name') }}
        </h3>
        <br/>

        <section
            class=" md:max-w-2xl  mx-auto flex  md:flex-nowrap items-center bg-gray-800 shadow-lg rounded-2xl py-6 md:py-4 px-6 md:pr-5 space-y-6 md:space-y-0 md:space-x-2 align-middle">
            <p class="flex-auto text-yellow-500 text-lg font-medium align-middle">
                Ofertas</p>
            <a href="/"
               class="flex-none bg-yellow-500 hover:bg-gray-100 transition-colors duration-200 text-gray-900 font-semibold rounded-lg py-3 px-4 align-middle">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" width="28" height="28"
                     stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M11 19l-7-7 7-7m8 14l-7-7 7-7"/>
                </svg>
            </a>
        </section>
        <br/>

        @foreach( $products as $product)
            <div class="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden md:max-w-2xl">

                <div class="md:flex">
                    <div class="md:flex-shrink-0 bg-red-500">
                        <img class="h-48 w-full object-cover md:w-48" src="/storage/{{$product->photo}}"
                             alt="{{$product->name}}">
                    </div>
                    <div class="p-8">
                        @if($product->offer)
                            <div class="animate-bounce flex space-x-5">
                                <div class="uppercase tracking-wide text-sm text-red-500 font-semibold">Oferta
                                </div>
                            </div>
                        @else
                            <div class="uppercase tracking-wide text-sm text-indigo-500 font-semibold"></div>
                        @endif
                        <a href="#"
                           class="block mt-1 text-lg leading-tight font-medium text-black hover:underline">{{$product->name}}</a>
                        <p class="mt-2 text-gray-500">{{$product->description}}
                            @if ($product->aller)
                                <br/>Alérgenos: {{$product->aller}}
                            @endif
                        </p>
                        @if ($product->offer)
                            <p class="text-right line-through">Precio: {{$product->price}}</p>
                            <p class=" uppercase tracking-wide text-sm text-red-500 font-semibold text-right">
                                Oferta: {{$product->offer_price}}</p>
                        @else
                            <p class=" uppercase tracking-wide text-sm text-black font-semibold text-right">
                                Precio: {{$product->price}}</p>

                        @endif
                    </div>
                </div>

            </div>
            <br/>
        @endforeach

    </div>

    <div class="copyright text-center text-white">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script>, made with <span class=" align-middle	 text-3xl text-red-500 ">♥</span> by
        <a href="https://cositt.com/" target="_blank">Cositt Technology&reg;</a> for a better web.
    </div>

</section>

<!-- AlpineJS Library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/alpinejs/2.8.0/alpine.js"></script>

</body>
</html>
