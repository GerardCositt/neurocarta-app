<x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">Gestión de marinajes</h2>
</x-slot>
<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            @if (session()->has('message'))

                <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3"
                     role="alert">

                    <div class="flex">

                        <div>

                            <p class="text-sm">{{ session('message') }}</p>

                        </div>

                    </div>

                </div>

            @endif

            <button wire:click="create()"
                    class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded my-3">Agregar maridaje
            </button>

            @if($isOpen)

                @include('livewire.create')

            @endif
                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">

            <div>
                <table class="table-auto w-full">
                    <thead class="py-2 px-3 sticky top-0 border-b border-gray-200 bg-gray-200">
                    <tr>
                        <th class="px-4 py-2 w-1">Ocultar</th>
                        <th class="px-4 py-2 text-left">Nombre</th>
                        <th class="px-4 py-2 text-left">Descripción</th>
                        <th class="px-4 py-2 ">Acción</th>
                    </tr>
                    </thead>
                    <tbody>
                    @forelse($pairings as $pairing)
                        <tr @if($loop->even)class="bg-grey-200"@endif>
                            <td class="border-dashed border-t border-gray-200  px-4 py-2">
                                <label
                                    class="text-teal-500 inline-flex justify-between items-center hover:bg-gray-200 px-2 py-2 rounded-lg cursor-pointer">
                                    <input type="checkbox" class="form-checkbox rowCheckbox focus:outline-none focus:shadow-outline"
                                           wire:click="toggleState({{$pairing->id}})" {{ $pairing->active ? 'checked' : '' }}>
                                </label>
                            </td>

                            <td class="border-dashed border-t border-gray-200  px-4 py-2"><p class="{{ $pairing->active ? 'line-through' : '' }}">{{ $pairing->name }}</p></td>

                            <td class="border-dashed border-t border-gray-200  px-4 py-2"><p class="{{ $pairing->active ? 'line-through' : '' }}">{{ $pairing->description }}</p></td>

                            <td class="border-dashed border-t border-gray-200  px-4 py-2">

                                <div class="inline-flex space-x-4">

                                    <div class="flex-1 ">

                                    <div wire:click="edit({{ $pairing->id }})">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" fill="none"
                                             viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"
                                             stroke-linecap="round" stroke-linejoin="round"
                                             class="feather stroke-current text-green-600 feather-x cursor-pointer hover:text-green-400 rounded-full w-5 h-5 ml-2">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                        </svg>
                                    </div>
                                    </div>
                                    <div class="flex-1 ">
                                    <div wire:click="delete({{ $pairing->id }})">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" fill="none"
                                             viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"
                                             stroke-linecap="round" stroke-linejoin="round"
                                             class="feather stroke-current text-red-600 feather-x cursor-pointer hover:text-red-400 rounded-full w-5 h-5 ml-2">
                                            <line x1="18" y1="6" x2="6" y2="18"></line>
                                            <line x1="6" y1="6" x2="18" y2="18"></line>
                                        </svg>
                                    </div>
                                    </div>
                                </div>

                            </td>

                        </tr>

                        @empty
                            <tr>
                                <td colspan="3" class="text-center">
                                    {{ __('Aún no has creado categorias') }}
                                </td>
                            </tr>
                        @endforelse

                    </tbody>

                </table>
            </div>
        </div>

    </div>

</div>
