<div class="fixed z-10 inset-0 overflow-y-auto ease-out duration-400">

    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">


        <div class="fixed inset-0 transition-opacity">

            <div class="absolute inset-0 bg-gray-500 opacity-75"></div>

        </div>


        <!-- This element is to trick the browser into centering the modal contents. -->

        <span class="hidden sm:inline-block sm:align-middle sm:h-screen"></span>


        <div
            class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full"
            role="dialog" aria-modal="true" aria-labelledby="modal-headline">

            <form>

                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">

                    <div class="">

                        <div class="mb-4">

                            <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Nombre:</label>

                            <input type="text"
                                   class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                   id="name" placeholder="Escribe el Nombre" wire:model="name">

                            @error('name') <span class="text-red-500">{{ $message }}</span>@enderror

                        </div>


                        <div class="mb-4 inline-flex space-x-4">

                            @if ($photo && !$filename)
                                <div class="flex-2">
                                    Foto actual:
                                    <img src="/storage/{{ $photo }}" width="120px">
                                </div>
                            @endif

                            @if ($filename)
                                <div class="flex-2">
                                    Nueva foto:
                                    <img src="{{ $filename->temporaryUrl() }}" height="120px">
                                </div>
                            @endif
                            <div class="flex-2">
                                <label for="filename" class="block text-gray-700 text-sm font-bold mb-2">Foto:</label>

                                <input type="file"
                                       class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                       id="filename" placeholder="seleccionar foto" wire:model="filename">

                                @error('photo') <span class="text-red-500">{{ $message }}</span>@enderror

                                @error('filename') <span class="text-red-500">{{ $message }}</span>@enderror
                            </div>
                        </div>


                        <div class="mb-4 inline-flex space-x-4">
                            <div class="flex-2">
                                <label for="category_id"
                                       class="block text-gray-700 text-sm font-bold mb-2">Categoría:</label>

                                <select id="category_id"
                                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                        name="category_id" wire:model="category_id">
                                    <option value="">Selecciona una categoría</option>
                                    @foreach($categories as $category)
                                        <option value="{{$category->id}}">{{$category->name}}</option>
                                    @endforeach
                                </select>
                                @error('category_id') <span class="text-red-500">{{ $message }}</span>@enderror

                            </div>
                            <div class="flex-2">

                                <label for="pairing" class="block text-gray-700 text-sm font-bold mb-2">Asignar maridaje:</label>

                                <select id="pairing"
                                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                        name="pairing_id" wire:model="pairing_id">
                                    <option value="">Ninguno </option>
                                    @foreach($pairings as $pairing)
                                        <option value="{{$pairing->id}}">{{$pairing->name}}</option>
                                    @endforeach
                                </select>
                                @error('pairing_id') <span class="text-red-500">{{ $message }}</span>@enderror

                            </div>
                        </div>

                        <div class="mb-4 inline-flex space-x-4 ">
                            <div class="flex-1">
                                <label for="price" class="block text-gray-700 text-sm font-bold mb-2">Precio:</label>

                                <input type="text"
                                       class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                       id="price" placeholder="" wire:model="price">

                                @error('price') <span class="text-red-500">{{ $message }}</span>@enderror

                            </div>
                            <div class="flex-1">
                                <label for="offer_price" class="block text-gray-700 text-sm font-bold mb-2">Precio
                                    Oferta:</label>

                                <input type="text"
                                       class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                       id="offer_price" placeholder="" wire:model="offer_price">

                                @error('offer_price') <span class="text-red-500">{{ $message }}</span>@enderror
                            </div>
                        </div>


                        <div class="mb-4">

                            <label for="description"
                                   class="block text-gray-700 text-sm font-bold mb-2">Descripción:</label>

                            <textarea
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="description" wire:model="description"
                                placeholder="Escribir la descripción"></textarea>

                            @error('description') <span class="text-red-500">{{ $message }}</span>@enderror

                        </div>

                        <div class="mb-4">

                            <label for="aller"
                                   class="block text-gray-700 text-sm font-bold mb-2">Alérgenos:</label>

                            <textarea
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="aller" wire:model="aller"
                                placeholder="Escribir la descripción"></textarea>

                            @error('aller') <span class="text-red-500">{{ $message }}</span>@enderror

                        </div>


                    </div>

                </div>


                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">

        <span class="flex w-full rounded-md shadow-sm sm:ml-3 sm:w-auto">

          <button wire:click.prevent="store()" type="button"
                  class="inline-flex justify-center w-full rounded-md border border-transparent px-4 py-2 bg-green-600 text-base leading-6 font-medium text-white shadow-sm hover:bg-green-500 focus:outline-none focus:border-green-700 focus:shadow-outline-green transition ease-in-out duration-150 sm:text-sm sm:leading-5">

            Guardar

          </button>

        </span>

                    <span class="mt-3 flex w-full rounded-md shadow-sm sm:mt-0 sm:w-auto">



          <button wire:click="closeModal()" type="button"
                  class="inline-flex justify-center w-full rounded-md border border-gray-300 px-4 py-2 bg-white text-base leading-6 font-medium text-gray-700 shadow-sm hover:text-gray-500 focus:outline-none focus:border-blue-300 focus:shadow-outline-blue transition ease-in-out duration-150 sm:text-sm sm:leading-5">

            Cancelar

          </button>

        </span>

            </form>

        </div>


    </div>

</div>

</div>
