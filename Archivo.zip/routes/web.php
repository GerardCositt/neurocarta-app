<?php

use Illuminate\Support\Facades\Route;
use App\Http\Livewire\Pairings;
use App\Http\Livewire\Products;
use App\Http\Controllers\ProductController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('menu');
//});

Route::get('/',[ProductController::class,'index'])->name('menu');
Route::get('/list/offer',[ProductController::class,'offer'])->name('offer');
Route::get('/list/{category?}',[ProductController::class,'index'])->name('menulist');


Route::middleware(['auth:sanctum', 'verified'])->get('/dashboard', function () {
    return view('dashboard');
})->name('dashboard');

Route::middleware(['auth:sanctum', 'verified'])->get('/category', function () {
    return view('category');
})->name('category_list');

Route::middleware(['auth:sanctum', 'verified'])->get('/allergen', function () {
    return view('allergen');
})->name('allergen_list');

Route::middleware(['auth:sanctum', 'verified'])->get('/advice', function () {
    return view('advice');
})->name('advice');

Route::get('/pairing', Pairings::class);
Route::get('/product', Products::class);
