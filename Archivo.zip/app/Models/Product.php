<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    protected $fillable = [
        'name',
        'description',
        'active',
        'category_id',
        'pairing_id',
        'price',
        'photo',
        'offer_price',
        'aller',

    ];


    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function pairing()
    {
        return $this->belongsTo(Pairing::class);
    }

//    public function allergens()
//    {
//
//        return $this->belongsToMany(Allergen::class);
//    }
}
