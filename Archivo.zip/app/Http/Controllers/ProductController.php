<?php

namespace App\Http\Controllers;

use App\Models\Advice;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Foundation\Console\PolicyMakeCommand;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Category|null $category
     * @return \Illuminate\Http\Response
     */
    public function index(Category $category = null)
    {

        $advices = Advice::where('status', 1)->orderBy('created_at', 'desc')->get();
        $showAlerts = $advices->count() > 0 ? $this->spash() : 0;

//        $showAlerts = 1; //activar para test

        $categories = $category ? Category::where('active', 0)->where('id', $category->id)->get() : $categories = Category::where('active', 0)->get();

        $showOffer = $categories->count() >= 2 && Product::where('active', 0)->where('offer', 1)->count() >= 1;

        return view('menu', compact('categories', 'showOffer', 'showAlerts', 'advices'));

    }

    private function spash()
    {
        if (session()->missing('splash')) {
            session(['splash' => 'false']);
            return 1;
        } else {
            return 0;
        }
    }

    public function offer()
    {

        $products = Product::where('active', 0)->where('offer', 1)->get();

        return view('menulist', compact('products'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param \App\Models\Product $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\Models\Product $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Models\Product $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Models\Product $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        //
    }
}
