<?php

namespace App\Http\Livewire\Allergen;

use App\Models\Allergen;
use Illuminate\Database\Eloquent\Collection;
use Livewire\Component;

class Show extends Component
{
    public Collection $allergens;

    public $msgError;

    protected $listeners = ['allergenCreated'];

    public function render()
    {
        $this->allergens = Allergen::all();

        return view('livewire.allergen.show');
    }

    public function allergenCreated():void
    {
        $this->render();

    }

    public function toggleState(Allergen $allergen): void
    {
        $allergen->active = !$allergen->active;
        $allergen->save();
    }

    public function deleteAllergen(Allergen $allergen): void
    {
        if ($allergen->products()->count() == 0)
        {

            $allergen->delete();
        } else {

            $this->msgError ='El alérgeno no se puede eliminar al encontrarse asignado a un producto, por favor elimine la asociación primero';

        }

    }
}
