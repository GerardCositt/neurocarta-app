<?php

namespace App\Http\Livewire\Category;

use App\Models\Category;
use Illuminate\Database\Eloquent\Collection;
use Livewire\Component;

class Show extends Component
{
    public Collection $categories;
    public $msgError;


    protected $listeners = ['categoryCreated'];

    public function render()
    {
        $this->categories = Category::all();
        return view('livewire.category.show');
    }

    public function categoryCreated():void
    {
        $this->render();

    }

    public function toggleState(Category $category): void
    {
        $category->active = !$category->active;
        $category->save();
    }

    public function deleteCategory(Category $category): void
    {
        if ($category->products()->count() == 0)
        {

            $category->delete();
        } else {

            $this->msgError ='La categoría no se puede eliminar al no encontrarse vacia, por favor vacíala para poder eliminarla';

        }

    }


}
