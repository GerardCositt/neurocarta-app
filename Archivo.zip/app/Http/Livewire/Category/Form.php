<?php

namespace App\Http\Livewire\Category;

use App\Models\Category;
use Livewire\Component;

class Form extends Component
{
    public Category $category;

    protected array $rules = [
        'category.name' => 'required|min:3',
    ];

    public function mount()
    {
        $this->category = app(Category::class);
    }

    public function render()
    {

        return view('livewire.category.form');
    }

    public function createCategory(): void
    {
        $this->validate();
        Category::create([
            "name" => $this->category->name,
        ]);

        $this->category->name ="";

        $this->emit('categoryCreated');
    }

}
