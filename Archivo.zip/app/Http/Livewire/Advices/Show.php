<?php

namespace App\Http\Livewire\Advices;

use App\Models\Advice;
use Livewire\Component;
use Livewire\WithPagination;


class Show extends Component
{
    use WithPagination;

    public $active;
    public $q;
    public $sortBy = 'id';
    public $sortAsc = true;
    public $item;

    public $confirmingItemDeletion = false;
    public $confirmingItemAdd = false;

    protected $queryString = [
        'active' => ['except' => false],
        'q' => ['except' => ''],
        'sortBy' => ['except' => 'id'],
        'sortAsc' => ['except' => true],
    ];

    protected $rules = [
        'item.title' => 'required|string|min:4',
        'item.advice' => 'required|string|min:4',
//        'item.price' => 'required|numeric|between:1,100',
        'item.status' => 'boolean'
    ];

    public function render()
    {
        $items = Advice::when( $this->q, function($query) {
            return $query->where(function( $query) {
                $query->where('title', 'like', '%'.$this->q . '%');
            });
        })
            ->when($this->active, function( $query) {
                return $query->active();
            })
            ->orderBy( $this->sortBy, $this->sortAsc ? 'ASC' : 'DESC');

        $items = $items->paginate(10);

        return view('livewire.advices.show', [
            'items' => $items,
        ]);

    }
    public function updatingActive()
    {
        $this->resetPage();
    }

    public function updatingQ()
    {
        $this->resetPage();
    }

    public function sortBy( $field)
    {
        if( $field == $this->sortBy) {
            $this->sortAsc = !$this->sortAsc;
        }
        $this->sortBy = $field;
    }

    public function confirmItemDeletion( $id)
    {
        $this->confirmingItemDeletion = $id;
    }

    public function deleteItem( Advice $item)
    {
        $item->delete();
        $this->confirmingItemDeletion = false;
        session()->flash('message', 'Aviso eliminado correctamente');
    }

    public function confirmItemAdd()
    {
        $this->reset(['item']);
        $this->confirmingItemAdd = true;
    }

    public function confirmItemEdit(Advice $item)
    {
        $this->resetErrorBag();
        $this->item = $item;
        $this->confirmingItemAdd = true;
    }

    public function saveItem()
    {
        $this->validate();

        if( isset( $this->item->id)) {
            $this->item->save();
            session()->flash('message', 'Aviso guardado correctamente');
        } else {
            Advice::create([
                'title' => $this->item['title'],
                'advice' => $this->item['advice'],
                'status' => $this->item['status'] ?? 0
            ]);
            session()->flash('message', 'Aviso agregado correctamente');
        }

        $this->confirmingItemAdd = false;

    }

    public function toggleState(Advice $item): void
    {
        $item->status = !$item->status;
        $item->save();
    }
}
