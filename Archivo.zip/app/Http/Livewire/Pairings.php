<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Pairing;

class Pairings extends Component
{
    public $pairings, $name, $description, $pairing_id;
    public $isOpen = 0;


    public function render()
    {
        $this->pairings = Pairing::all();
        return view('livewire.pairings');
    }


    public function toggleState(Pairing $pairing): void
    {
        $pairing->active = !$pairing->active;
        $pairing->save();
    }
    public function create()
    {
        $this->resetInputFields();
        $this->openModal();
    }

    public function openModal()
    {
        $this->isOpen = true;
    }

    public function closeModal()
    {
        $this->isOpen = false;
    }

    private function resetInputFields(){

        $this->name = '';

        $this->description = '';

        $this->pairing_id = '';

    }

    public function store()

    {

        $this->validate([

            'name' => 'required',

            'description' => 'required',

        ]);



        Pairing::updateOrCreate(['id' => $this->pairing_id], [

            'name' => $this->name,

            'description' => $this->description

        ]);



        session()->flash('message',

            $this->pairing_id ? 'Meridaje actualizado correctamente.' : 'Meridaje creado correctamente.');



        $this->closeModal();

        $this->resetInputFields();

    }

    /**

     * The attributes that are mass assignable.

     *

     * @var array

     */

    public function edit($id)

    {

        $pairing = Pairing::findOrFail($id);

        $this->pairing_id = $id;

        $this->name = $pairing->name;

        $this->description = $pairing->description;


        $this->openModal();

    }



    /**

     * The attributes that are mass assignable.

     *

     * @var array

     */

    public function delete($id)

    {

        Pairing::find($id)->delete();

        session()->flash('message', 'Meridaje eliminado correctamente.');

    }



}
