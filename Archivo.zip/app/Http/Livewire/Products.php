<?php

namespace App\Http\Livewire;

use App\Models\Allergen;
use App\Models\Category;
use App\Models\Pairing;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use App\Models\Product;
use Livewire\WithFileUploads;
use Livewire\WithPagination;

class Products extends Component
{
    use WithFileUploads;
    use WithPagination;

    public $products, $name, $description, $product_id, $category_id, $pairing_id, $price, $offer_price, $categories, $pairings, $photo, $filename, $allergens, $aller;
    public $isOpen = 0;

    //agregamos variable para filtrar la query con un buscador
    public $q;

    protected $queryString = [
        'q' => ['except' => '']
    ];
//     public $selectedallergens =[];



    public function render()
    {
//consulta filtrada por el buscador
        $this->products = Product::when($this->q, function ($query){
            return $query->where('name', 'like', '%'. $this->q . '%');
        })->get();

//        $this->products = Product::all();
        $this->categories = Category::all();
        $this->pairings = Pairing::all();
//        $this->allergens =Allergen::all();

        return view('livewire.products');
    }


    public function toggleState(Product $product): void
    {
        $product->active = !$product->active;
        $product->save();
    }


    public function offerState(Product $product): void
    {
        $product->offer = !$product->offer;
        $product->save();
    }

    public function create()
    {
        $this->resetInputFields();
        $this->openModal();
    }

    public function openModal()
    {
        $this->isOpen = true;
    }

    public function closeModal()
    {
        $this->isOpen = false;
    }

    private function resetInputFields()
    {

        $this->name = '';
        $this->category_id = '';
        $this->price = '0';
        $this->offer_price = '';
        $this->description = '';
        $this->pairing_id = '';
        $this->product_id = '';
        $this->photo = '';
        $this->filename = '';
        $this->aller = '';

    }

    public function store()

    {

        $data = $this->validate([

            'name' => 'required',
            'category_id' => 'required',
            'price' => 'required',
            'offer_price' => '',
            'description' => 'required',
            'pairing_id' => '',
            'photo' => '',
            'filename' => 'nullable|image|mimes:jpg,jpeg,png,svg,gif|max:548',
            'aller' => '',

        ]);

//        $fichero = $this->filename->store('img', 'public');

        if ($data['filename'] != null) {

            if ($data['photo'] != null) {
                Storage::disk('public')->delete($data['photo']);
            }

            $data['photo'] = $this->filename->store('img', 'public');

        } else {
            unset($data['photo']);
        }

        $data['pairing_id'] = $this->pairing_id == 0 ? null : $this->pairing_id;

        Product::updateOrCreate(['id' => $this->product_id], $data);


        session()->flash('message',

            $this->product_id ? 'Producto actualizado correctamente.' : 'Producto creado correctamente.');


        $this->closeModal();

        $this->resetInputFields();

    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    public function edit($id)

    {

        $product = Product::findOrFail($id);

        $this->product_id = $id;

        $this->name = $product->name;

        $this->category_id = $product->category_id;

        $this->price = $product->price;

        $this->offer_price = $product->offer_price;

        $this->description = $product->description;

        $this->pairing_id = $product->pairing_id;

        $this->photo = $product->photo;

        $this->aller = $product->aller;

//        $this->selectedallergens = $product->allergens;



        $this->openModal();

    }


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    public function delete($id)

    {

        Product::find($id)->delete();

        session()->flash('message', 'Producto eliminado correctamente.');

    }


}
